---
name: Jamaica Jones
first_name: Jamaica
last_name: Jones
image_url: assets/images/jamaica_jones.jpeg
links:
#  - name: Profile
#    absolute_url:
---

CPSS/Barrios Technology/Project Coordinator, NASA TOPS Mission   
Executive Secretary, White House Office of Science and Technology Policy Subgroup on the Year of Open Science

### Bio

Jamaica Jones is the Program Coordinator of the NASA TOPS mission and serves as the Executive Secretary of the White House's Office of Science and Technology Policy Subgroup on the Year of Open Science 2023, coordinating federal interagency efforts to advance, inform and celebrate open science initiatives. 
She is also a PhD student at the University of Pittsburgh School of Computing and Information where she is pursuing research into scientific indicators, research assessment and open science.
