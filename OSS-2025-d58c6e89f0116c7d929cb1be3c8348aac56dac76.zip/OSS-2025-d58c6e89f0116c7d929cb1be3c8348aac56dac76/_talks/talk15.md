---
name: Introducing OpenAlex, an Open and Comprehensive Catalog of the World's Scholarly Research System
speakers:
  - Jason Portenoy
categories:
  - Open Access Publishing
  - Talk
---
