---
name: Panelist Q&A 2
speakers:
  - Monica Granados
  - Taiwo Lasisi
  - Malvika Sharan
categories:
  - Open Science and Communities
  - Talk
---
