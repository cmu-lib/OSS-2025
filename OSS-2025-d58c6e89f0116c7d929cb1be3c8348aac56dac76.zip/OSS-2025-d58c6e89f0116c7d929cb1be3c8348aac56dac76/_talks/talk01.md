---
name: Remote Control Science in the Cloud Lab
speakers:
  - Subha Das
categories:
  - Open Science in Research & Teaching
  - Talk
---
