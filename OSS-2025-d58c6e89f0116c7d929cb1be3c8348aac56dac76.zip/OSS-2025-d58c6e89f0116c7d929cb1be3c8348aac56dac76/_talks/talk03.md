---
name: An Introduction to the Open Energy Outlook Initiative
speakers:
  - Michael Blackhurst
categories:
  - Open Science in Research & Teaching
  - Talk
---
