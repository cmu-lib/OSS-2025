---
name: Panelist Q&A 1
speakers:
  - Subha Das
  - Sayeed Choudhury
  - Michael Blackhurst
categories:
  - Open Science in Research & Teaching
  - Talk
---
