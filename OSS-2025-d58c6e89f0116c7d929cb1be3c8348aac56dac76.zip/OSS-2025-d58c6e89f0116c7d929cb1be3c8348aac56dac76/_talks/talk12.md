---
name: Panelist Q&A 3
speakers:
  - LaKeisha Harris
  - Michael Dougherty
  - Jamaica Jones
categories:
  - Impact of Policies
  - Talk
---
