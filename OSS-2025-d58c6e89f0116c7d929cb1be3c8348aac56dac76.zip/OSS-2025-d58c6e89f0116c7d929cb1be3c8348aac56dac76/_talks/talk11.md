---
name: Transforming to Open Science at NASA and Beyond - A Year of Open Science
speakers:
  - Jamaica Jones
categories:
  - Impact of Policies
  - Talk
---
