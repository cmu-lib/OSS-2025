---
name: Aligning Incentives with Institutional Values
speakers:
  - Michael Dougherty
categories:
  - Impact of Policies
  - Talk
---
