---
name: Open Science for Enabling Reproducible, Ethical and Collaborative Research – Insights from The Turing Way Community
speakers:
  - Malvika Sharan
categories:
  - Open Science and Communities
  - Talk
---
