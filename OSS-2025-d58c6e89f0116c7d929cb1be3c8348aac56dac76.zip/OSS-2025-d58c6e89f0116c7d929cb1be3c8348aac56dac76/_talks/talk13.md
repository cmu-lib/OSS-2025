---
name: What’s Wrong with Open Access as a Model?
speakers:
  - Sanjiv Singh
categories:
  - Open Access Publishing
  - Talk
---
