---
name: Creating Community Data with Community Access for Community Needs
speakers:
  - Taiwo Lasisi
categories:
  - Open Science and Communities
  - Talk
---
