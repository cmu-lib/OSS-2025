---
name: What Pieces Do We Need in Open Policy to Enable Us to Solve the World’s Greatest Challenges
speakers:
  - Monica Granados
categories:
  - Open Science and Communities
  - Talk
---
