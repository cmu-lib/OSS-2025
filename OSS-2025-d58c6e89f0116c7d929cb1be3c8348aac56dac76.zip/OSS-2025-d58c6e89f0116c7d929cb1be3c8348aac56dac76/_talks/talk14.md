---
name: Supporting Open Science on a Small Budget - The Role of the Mines Repository
speakers:
  - Joseph Kraus
categories:
  - Open Access Publishing
  - Talk
---
