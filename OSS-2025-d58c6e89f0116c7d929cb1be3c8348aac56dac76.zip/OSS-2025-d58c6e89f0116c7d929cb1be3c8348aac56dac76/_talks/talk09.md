---
name: Higher Education Leadership Initiative for Open Scholarship (HELIOS)
speakers:
  - LaKeisha Harris
categories:
  - Impact of Policies
  - Talk
---
