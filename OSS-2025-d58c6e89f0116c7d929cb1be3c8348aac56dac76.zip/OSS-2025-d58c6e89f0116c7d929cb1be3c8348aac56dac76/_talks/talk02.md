---
name: A Rolling Wall of Openness
speakers:
  - Sayeed Choudhury
categories:
  - Open Science in Research & Teaching
  - Talk
---
