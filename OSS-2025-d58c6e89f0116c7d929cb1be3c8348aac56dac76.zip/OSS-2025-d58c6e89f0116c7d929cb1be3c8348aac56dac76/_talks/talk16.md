---
name: Panelist Q&A 4
speakers:
  - Sanjiv Singh
  - Joseph Kraus
  - Jason Portenoy
categories:
  - Open Access Publishing
  - Talk
---
