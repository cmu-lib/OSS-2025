---
name: Room C
---

A different way description on how to find this room