---
layout: location
---

This symposium will be held virtually starting at **9:00 AM EST (GMT-4)**.  

[Register here](https://www.eventbrite.com/e/open-science-symposium-2023-tickets-675423599167?aff=oddtdtcreator) to attend!
